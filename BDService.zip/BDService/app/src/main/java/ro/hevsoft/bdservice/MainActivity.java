package ro.hevsoft.bdservice;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.File;

import butterknife.BindView;

public class MainActivity extends AppCompatActivity implements ApkRepository.Listener {

    private static final String APK_URL = "192.168.0.39:5000/build";

    @BindView(R.id.textView)
    TextView textView;
    @BindView(R.id.btn_download)
    Button btn_download;
    @BindView(R.id.btn_install)
    Button btn_install;

    private ApkRepository apkRepository;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        apkRepository = new ApkRepository();


        btn_install.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                apkRepository.downloadApk(MainActivity.this,APK_URL,"build.apk",MainActivity.this);
            }
        });
    }

    @Override
    public void onSuccess(File result) {
        textView.setText(result.getAbsolutePath());
    }

    @Override
    public void onError() {

    }
}

package ro.hevsoft.bdservice;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

/**
 * Pentalog
 * Created by erusu on 6/14/2016.
 */
public interface GcmService {

    @FormUrlEncoded
    @POST("/register")
    Call<RegisterResponse> register(@Field("token") String token);
}

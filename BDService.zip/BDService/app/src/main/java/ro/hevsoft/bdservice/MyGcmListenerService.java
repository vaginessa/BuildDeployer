package ro.hevsoft.bdservice;

import android.app.IntentService;
import android.content.Intent;

/**
 * Pentalog
 * Created by erusu on 6/14/2016.
 */
public class MyGcmListenerService extends IntentService {


    /**
     * Creates an IntentService.  Invoked by your subclass's constructor.
     *
     */
    public MyGcmListenerService() {
        super("gcm-listener-service");
    }

    @Override
    protected void onHandleIntent(Intent intent) {

    }
}

package ro.hevsoft.bdservice;

import android.content.Context;

import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;

import java.io.File;

/**
 * Pentalog
 * Created by erusu on 6/13/2016.
 */
public class ApkRepository {

    /**
     * connect to server download the apk to a location
     */
    public void downloadApk(Context context, String apkUrl, String apkDestination, final Listener listener){
        Ion.with(context)
                .load(apkUrl)
                .write(new File("sdcard/apks/"+apkDestination))
                .setCallback(new FutureCallback<File>() {
                    @Override
                    public void onCompleted(Exception e, File result) {
                        if(e!= null){
                            e.printStackTrace();
                            listener.onError();
                        }else{
                            listener.onSuccess(result);
                        }
                    }
                });
    }

    public static interface Listener{
        public void onSuccess(File result);
        public void onError();
    }
}

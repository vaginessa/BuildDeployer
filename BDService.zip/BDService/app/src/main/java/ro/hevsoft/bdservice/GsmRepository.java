package ro.hevsoft.bdservice;

/**
 * Pentalog
 * Created by erusu on 6/14/2016.
 */
public class GsmRepository {

    public void register(){

    }
}
